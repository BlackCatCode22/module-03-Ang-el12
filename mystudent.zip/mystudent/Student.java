package mystudent;

public class Student {
    String firstName;
    String lastname;
    int age;
    double gpa;
    String major;
    String city;
    String state;
    int idNumber;
    String year;
}